﻿namespace GymTuto
{
    partial class MemList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MemList));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.AmountTb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.priceTblBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.u1707856_gymdbDataSet = new GymTuto.u1707856_gymdbDataSet();
            this.priceTblBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.gymDBDataSet = new GymTuto.GymDBDataSet();
            this.priceTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cUSERSAFWADMINDOCUMENTSGYMDBMDFDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this._C__USERS_AFWADMIN_DOCUMENTS_GYMDB_MDFDataSet = new GymTuto._C__USERS_AFWADMIN_DOCUMENTS_GYMDB_MDFDataSet();
            this.GenderCb = new System.Windows.Forms.ComboBox();
            this.bookTblBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.bookTblBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.bookTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.PhoneTb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label4 = new System.Windows.Forms.Label();
            this.NameTb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.memberTblBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.memberTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.bookTblTableAdapter = new GymTuto._C__USERS_AFWADMIN_DOCUMENTS_GYMDB_MDFDataSetTableAdapters.BookTblTableAdapter();
            this.label16 = new System.Windows.Forms.Label();
            this.AgeTb = new System.Windows.Forms.ComboBox();
            this.priceTblTableAdapter = new GymTuto._C__USERS_AFWADMIN_DOCUMENTS_GYMDB_MDFDataSetTableAdapters.PriceTblTableAdapter();
            this.memberTblTableAdapter = new GymTuto.GymDBDataSetTableAdapters.MemberTblTableAdapter();
            this.bookTblTableAdapter1 = new GymTuto.GymDBDataSetTableAdapters.BookTblTableAdapter();
            this.priceTblTableAdapter1 = new GymTuto.GymDBDataSetTableAdapters.PriceTblTableAdapter();
            this.memberTblTableAdapter1 = new GymTuto.u1707856_gymdbDataSetTableAdapters.MemberTblTableAdapter();
            this.SumLbl = new System.Windows.Forms.Label();
            this.SumBtn = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button5 = new System.Windows.Forms.Button();
            this.SearchBtn = new System.Windows.Forms.Button();
            this.SearchClient = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.priceTblTableAdapter2 = new GymTuto.u1707856_gymdbDataSetTableAdapters.PriceTblTableAdapter();
            this.bookTblTableAdapter2 = new GymTuto.u1707856_gymdbDataSetTableAdapters.BookTblTableAdapter();
            this.TypeCb = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.MemberSDGV = new Guna.UI2.WinForms.Guna2DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.priceTblBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.u1707856_gymdbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.priceTblBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gymDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.priceTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSERSAFWADMINDOCUMENTSGYMDBMDFDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__USERS_AFWADMIN_DOCUMENTS_GYMDB_MDFDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookTblBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookTblBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.memberTblBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.memberTblBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MemberSDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Crimson;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(625, 613);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(127, 34);
            this.button4.TabIndex = 43;
            this.button4.Text = "Назад";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Crimson;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(75, 564);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(139, 34);
            this.button3.TabIndex = 42;
            this.button3.Text = "Удалить";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Crimson;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(75, 613);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(139, 34);
            this.button2.TabIndex = 41;
            this.button2.Text = "Сбросить";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Crimson;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(75, 514);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(139, 34);
            this.button1.TabIndex = 40;
            this.button1.Text = "Изменить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(20, 429);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 19);
            this.label8.TabIndex = 37;
            this.label8.Text = "Цена:";
            // 
            // AmountTb
            // 
            this.AmountTb.BackColor = System.Drawing.Color.White;
            this.AmountTb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AmountTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.AmountTb.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.priceTblBindingSource2, "PPrice", true));
            this.AmountTb.Enabled = false;
            this.AmountTb.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AmountTb.ForeColor = System.Drawing.Color.Black;
            this.AmountTb.HintForeColor = System.Drawing.Color.Empty;
            this.AmountTb.HintText = "";
            this.AmountTb.isPassword = false;
            this.AmountTb.LineFocusedColor = System.Drawing.Color.White;
            this.AmountTb.LineIdleColor = System.Drawing.Color.White;
            this.AmountTb.LineMouseHoverColor = System.Drawing.Color.White;
            this.AmountTb.LineThickness = 4;
            this.AmountTb.Location = new System.Drawing.Point(24, 453);
            this.AmountTb.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.AmountTb.Name = "AmountTb";
            this.AmountTb.Size = new System.Drawing.Size(252, 32);
            this.AmountTb.TabIndex = 36;
            this.AmountTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AmountTb.OnValueChanged += new System.EventHandler(this.AmountTb_OnValueChanged);
            // 
            // priceTblBindingSource2
            // 
            this.priceTblBindingSource2.DataMember = "PriceTbl";
            this.priceTblBindingSource2.DataSource = this.u1707856_gymdbDataSet;
            // 
            // u1707856_gymdbDataSet
            // 
            this.u1707856_gymdbDataSet.DataSetName = "u1707856_gymdbDataSet";
            this.u1707856_gymdbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // priceTblBindingSource1
            // 
            this.priceTblBindingSource1.DataMember = "PriceTbl";
            this.priceTblBindingSource1.DataSource = this.gymDBDataSet;
            // 
            // gymDBDataSet
            // 
            this.gymDBDataSet.DataSetName = "GymDBDataSet";
            this.gymDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // priceTblBindingSource
            // 
            this.priceTblBindingSource.DataMember = "PriceTbl";
            this.priceTblBindingSource.DataSource = this.cUSERSAFWADMINDOCUMENTSGYMDBMDFDataSetBindingSource;
            // 
            // cUSERSAFWADMINDOCUMENTSGYMDBMDFDataSetBindingSource
            // 
            this.cUSERSAFWADMINDOCUMENTSGYMDBMDFDataSetBindingSource.DataSource = this._C__USERS_AFWADMIN_DOCUMENTS_GYMDB_MDFDataSet;
            this.cUSERSAFWADMINDOCUMENTSGYMDBMDFDataSetBindingSource.Position = 0;
            // 
            // _C__USERS_AFWADMIN_DOCUMENTS_GYMDB_MDFDataSet
            // 
            this._C__USERS_AFWADMIN_DOCUMENTS_GYMDB_MDFDataSet.DataSetName = "_C__USERS_AFWADMIN_DOCUMENTS_GYMDB_MDFDataSet";
            this._C__USERS_AFWADMIN_DOCUMENTS_GYMDB_MDFDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // GenderCb
            // 
            this.GenderCb.DataSource = this.bookTblBindingSource2;
            this.GenderCb.DisplayMember = "BTitle";
            this.GenderCb.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GenderCb.FormattingEnabled = true;
            this.GenderCb.Location = new System.Drawing.Point(24, 251);
            this.GenderCb.Name = "GenderCb";
            this.GenderCb.Size = new System.Drawing.Size(252, 31);
            this.GenderCb.TabIndex = 35;
            this.GenderCb.SelectedIndexChanged += new System.EventHandler(this.GenderCb_SelectedIndexChanged);
            // 
            // bookTblBindingSource2
            // 
            this.bookTblBindingSource2.DataMember = "BookTbl";
            this.bookTblBindingSource2.DataSource = this.u1707856_gymdbDataSet;
            // 
            // bookTblBindingSource1
            // 
            this.bookTblBindingSource1.DataMember = "BookTbl";
            this.bookTblBindingSource1.DataSource = this.gymDBDataSet;
            // 
            // bookTblBindingSource
            // 
            this.bookTblBindingSource.DataMember = "BookTbl";
            this.bookTblBindingSource.DataSource = this.cUSERSAFWADMINDOCUMENTSGYMDBMDFDataSetBindingSource;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(20, 229);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(167, 19);
            this.label7.TabIndex = 34;
            this.label7.Text = "Персональный тренер:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(20, 155);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 19);
            this.label5.TabIndex = 31;
            this.label5.Text = "Номер телефона:";
            // 
            // PhoneTb
            // 
            this.PhoneTb.BackColor = System.Drawing.Color.White;
            this.PhoneTb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PhoneTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PhoneTb.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PhoneTb.ForeColor = System.Drawing.Color.Black;
            this.PhoneTb.HintForeColor = System.Drawing.Color.Empty;
            this.PhoneTb.HintText = "";
            this.PhoneTb.isPassword = false;
            this.PhoneTb.LineFocusedColor = System.Drawing.Color.Maroon;
            this.PhoneTb.LineIdleColor = System.Drawing.Color.Crimson;
            this.PhoneTb.LineMouseHoverColor = System.Drawing.Color.LightCoral;
            this.PhoneTb.LineThickness = 4;
            this.PhoneTb.Location = new System.Drawing.Point(24, 179);
            this.PhoneTb.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.PhoneTb.Name = "PhoneTb";
            this.PhoneTb.Size = new System.Drawing.Size(252, 32);
            this.PhoneTb.TabIndex = 30;
            this.PhoneTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(20, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 19);
            this.label4.TabIndex = 29;
            this.label4.Text = "ФИО клиента:";
            // 
            // NameTb
            // 
            this.NameTb.BackColor = System.Drawing.Color.White;
            this.NameTb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.NameTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.NameTb.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NameTb.ForeColor = System.Drawing.Color.Black;
            this.NameTb.HintForeColor = System.Drawing.Color.Empty;
            this.NameTb.HintText = "";
            this.NameTb.isPassword = false;
            this.NameTb.LineFocusedColor = System.Drawing.Color.Maroon;
            this.NameTb.LineIdleColor = System.Drawing.Color.Crimson;
            this.NameTb.LineMouseHoverColor = System.Drawing.Color.LightCoral;
            this.NameTb.LineThickness = 4;
            this.NameTb.Location = new System.Drawing.Point(24, 115);
            this.NameTb.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.NameTb.Name = "NameTb";
            this.NameTb.Size = new System.Drawing.Size(252, 31);
            this.NameTb.TabIndex = 28;
            this.NameTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // memberTblBindingSource1
            // 
            this.memberTblBindingSource1.DataMember = "MemberTbl";
            this.memberTblBindingSource1.DataSource = this.u1707856_gymdbDataSet;
            // 
            // memberTblBindingSource
            // 
            this.memberTblBindingSource.DataMember = "MemberTbl";
            this.memberTblBindingSource.DataSource = this.gymDBDataSet;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Crimson;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1494, 55);
            this.panel1.TabIndex = 52;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(534, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(388, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "ВСЕ ПРОДАННЫЕ АБОНЕМЕНТЫ";
            // 
            // bookTblTableAdapter
            // 
            this.bookTblTableAdapter.ClearBeforeFill = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(20, 295);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(142, 19);
            this.label16.TabIndex = 56;
            this.label16.Text = "Кол-во тренировок:";
            // 
            // AgeTb
            // 
            this.AgeTb.DataSource = this.priceTblBindingSource2;
            this.AgeTb.DisplayMember = "PTime";
            this.AgeTb.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AgeTb.FormattingEnabled = true;
            this.AgeTb.Location = new System.Drawing.Point(24, 317);
            this.AgeTb.Name = "AgeTb";
            this.AgeTb.Size = new System.Drawing.Size(252, 31);
            this.AgeTb.TabIndex = 58;
            this.AgeTb.SelectedIndexChanged += new System.EventHandler(this.AgeTb_SelectedIndexChanged);
            // 
            // priceTblTableAdapter
            // 
            this.priceTblTableAdapter.ClearBeforeFill = true;
            // 
            // memberTblTableAdapter
            // 
            this.memberTblTableAdapter.ClearBeforeFill = true;
            // 
            // bookTblTableAdapter1
            // 
            this.bookTblTableAdapter1.ClearBeforeFill = true;
            // 
            // priceTblTableAdapter1
            // 
            this.priceTblTableAdapter1.ClearBeforeFill = true;
            // 
            // memberTblTableAdapter1
            // 
            this.memberTblTableAdapter1.ClearBeforeFill = true;
            // 
            // SumLbl
            // 
            this.SumLbl.BackColor = System.Drawing.Color.White;
            this.SumLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SumLbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SumLbl.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SumLbl.Location = new System.Drawing.Point(1267, 91);
            this.SumLbl.Name = "SumLbl";
            this.SumLbl.Size = new System.Drawing.Size(132, 33);
            this.SumLbl.TabIndex = 60;
            this.SumLbl.Text = "              ";
            this.SumLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SumBtn
            // 
            this.SumBtn.BackColor = System.Drawing.Color.Crimson;
            this.SumBtn.FlatAppearance.BorderSize = 0;
            this.SumBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SumBtn.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SumBtn.ForeColor = System.Drawing.Color.White;
            this.SumBtn.Location = new System.Drawing.Point(1128, 91);
            this.SumBtn.Name = "SumBtn";
            this.SumBtn.Size = new System.Drawing.Size(141, 33);
            this.SumBtn.TabIndex = 59;
            this.SumBtn.Text = "Общая сумма";
            this.SumBtn.UseVisualStyleBackColor = false;
            this.SumBtn.Click += new System.EventHandler(this.SumBtn_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(371, 91);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(33, 33);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 64;
            this.pictureBox2.TabStop = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Crimson;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(769, 91);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(106, 33);
            this.button5.TabIndex = 63;
            this.button5.Text = "Обновить";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // SearchBtn
            // 
            this.SearchBtn.BackColor = System.Drawing.Color.Crimson;
            this.SearchBtn.FlatAppearance.BorderSize = 0;
            this.SearchBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SearchBtn.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SearchBtn.ForeColor = System.Drawing.Color.White;
            this.SearchBtn.Location = new System.Drawing.Point(646, 91);
            this.SearchBtn.Name = "SearchBtn";
            this.SearchBtn.Size = new System.Drawing.Size(106, 33);
            this.SearchBtn.TabIndex = 62;
            this.SearchBtn.Text = "Найти";
            this.SearchBtn.UseVisualStyleBackColor = false;
            this.SearchBtn.Click += new System.EventHandler(this.SearchBtn_Click);
            // 
            // SearchClient
            // 
            this.SearchClient.BackColor = System.Drawing.Color.White;
            this.SearchClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SearchClient.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SearchClient.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SearchClient.ForeColor = System.Drawing.Color.Black;
            this.SearchClient.HintForeColor = System.Drawing.Color.Empty;
            this.SearchClient.HintText = "";
            this.SearchClient.isPassword = false;
            this.SearchClient.LineFocusedColor = System.Drawing.Color.Maroon;
            this.SearchClient.LineIdleColor = System.Drawing.Color.Crimson;
            this.SearchClient.LineMouseHoverColor = System.Drawing.Color.LightCoral;
            this.SearchClient.LineThickness = 4;
            this.SearchClient.Location = new System.Drawing.Point(412, 91);
            this.SearchClient.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.SearchClient.Name = "SearchClient";
            this.SearchClient.Size = new System.Drawing.Size(236, 33);
            this.SearchClient.TabIndex = 61;
            this.SearchClient.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // priceTblTableAdapter2
            // 
            this.priceTblTableAdapter2.ClearBeforeFill = true;
            // 
            // bookTblTableAdapter2
            // 
            this.bookTblTableAdapter2.ClearBeforeFill = true;
            // 
            // TypeCb
            // 
            this.TypeCb.DataSource = this.priceTblBindingSource2;
            this.TypeCb.DisplayMember = "PType";
            this.TypeCb.Enabled = false;
            this.TypeCb.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TypeCb.FormattingEnabled = true;
            this.TypeCb.Location = new System.Drawing.Point(24, 386);
            this.TypeCb.Name = "TypeCb";
            this.TypeCb.Size = new System.Drawing.Size(252, 31);
            this.TypeCb.TabIndex = 71;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(20, 364);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 19);
            this.label2.TabIndex = 70;
            this.label2.Text = "Тип тренировки:";
            // 
            // MemberSDGV
            // 
            this.MemberSDGV.AllowUserToAddRows = false;
            this.MemberSDGV.AllowUserToDeleteRows = false;
            this.MemberSDGV.AllowUserToResizeColumns = false;
            this.MemberSDGV.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.MemberSDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.MemberSDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.MemberSDGV.BackgroundColor = System.Drawing.Color.White;
            this.MemberSDGV.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MemberSDGV.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.MemberSDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Crimson;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Crimson;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.MemberSDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.MemberSDGV.ColumnHeadersHeight = 30;
            this.MemberSDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.MemberSDGV.DefaultCellStyle = dataGridViewCellStyle3;
            this.MemberSDGV.EnableHeadersVisualStyles = false;
            this.MemberSDGV.GridColor = System.Drawing.Color.Silver;
            this.MemberSDGV.Location = new System.Drawing.Point(315, 155);
            this.MemberSDGV.Name = "MemberSDGV";
            this.MemberSDGV.ReadOnly = true;
            this.MemberSDGV.RowHeadersVisible = false;
            this.MemberSDGV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.MemberSDGV.RowTemplate.Height = 30;
            this.MemberSDGV.RowTemplate.ReadOnly = true;
            this.MemberSDGV.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.MemberSDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.MemberSDGV.Size = new System.Drawing.Size(1157, 401);
            this.MemberSDGV.TabIndex = 72;
            this.MemberSDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.MemberSDGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.MemberSDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.MemberSDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.MemberSDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.MemberSDGV.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.MemberSDGV.ThemeStyle.GridColor = System.Drawing.Color.Silver;
            this.MemberSDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.Crimson;
            this.MemberSDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.MemberSDGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MemberSDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.MemberSDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.MemberSDGV.ThemeStyle.HeaderStyle.Height = 30;
            this.MemberSDGV.ThemeStyle.ReadOnly = true;
            this.MemberSDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.MemberSDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Single;
            this.MemberSDGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MemberSDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.MemberSDGV.ThemeStyle.RowsStyle.Height = 30;
            this.MemberSDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.Gainsboro;
            this.MemberSDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.MemberSDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MemberSDGV_CellContentClick_1);
            // 
            // MemList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(1494, 667);
            this.Controls.Add(this.MemberSDGV);
            this.Controls.Add(this.TypeCb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.SearchBtn);
            this.Controls.Add(this.SearchClient);
            this.Controls.Add(this.SumLbl);
            this.Controls.Add(this.SumBtn);
            this.Controls.Add(this.AgeTb);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.AmountTb);
            this.Controls.Add(this.GenderCb);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.PhoneTb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.NameTb);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MemList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.Load += new System.EventHandler(this.UpdateDelete_Load);
            ((System.ComponentModel.ISupportInitialize)(this.priceTblBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.u1707856_gymdbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.priceTblBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gymDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.priceTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSERSAFWADMINDOCUMENTSGYMDBMDFDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._C__USERS_AFWADMIN_DOCUMENTS_GYMDB_MDFDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookTblBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookTblBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.memberTblBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.memberTblBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MemberSDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label8;
        private Bunifu.Framework.UI.BunifuMaterialTextbox AmountTb;
        private System.Windows.Forms.ComboBox GenderCb;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private Bunifu.Framework.UI.BunifuMaterialTextbox PhoneTb;
        private System.Windows.Forms.Label label4;
        private Bunifu.Framework.UI.BunifuMaterialTextbox NameTb;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.BindingSource cUSERSAFWADMINDOCUMENTSGYMDBMDFDataSetBindingSource;
        private _C__USERS_AFWADMIN_DOCUMENTS_GYMDB_MDFDataSet _C__USERS_AFWADMIN_DOCUMENTS_GYMDB_MDFDataSet;
        private System.Windows.Forms.BindingSource bookTblBindingSource;
        private _C__USERS_AFWADMIN_DOCUMENTS_GYMDB_MDFDataSetTableAdapters.BookTblTableAdapter bookTblTableAdapter;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox AgeTb;
        private System.Windows.Forms.BindingSource priceTblBindingSource;
        private _C__USERS_AFWADMIN_DOCUMENTS_GYMDB_MDFDataSetTableAdapters.PriceTblTableAdapter priceTblTableAdapter;
        private GymDBDataSet gymDBDataSet;
        private System.Windows.Forms.BindingSource memberTblBindingSource;
        private GymDBDataSetTableAdapters.MemberTblTableAdapter memberTblTableAdapter;
        private System.Windows.Forms.BindingSource bookTblBindingSource1;
        private GymDBDataSetTableAdapters.BookTblTableAdapter bookTblTableAdapter1;
        private System.Windows.Forms.BindingSource priceTblBindingSource1;
        private GymDBDataSetTableAdapters.PriceTblTableAdapter priceTblTableAdapter1;
        private u1707856_gymdbDataSet u1707856_gymdbDataSet;
        private System.Windows.Forms.BindingSource memberTblBindingSource1;
        private u1707856_gymdbDataSetTableAdapters.MemberTblTableAdapter memberTblTableAdapter1;
        private System.Windows.Forms.Label SumLbl;
        private System.Windows.Forms.Button SumBtn;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button SearchBtn;
        private Bunifu.Framework.UI.BunifuMaterialTextbox SearchClient;
        private System.Windows.Forms.BindingSource priceTblBindingSource2;
        private u1707856_gymdbDataSetTableAdapters.PriceTblTableAdapter priceTblTableAdapter2;
        private System.Windows.Forms.BindingSource bookTblBindingSource2;
        private u1707856_gymdbDataSetTableAdapters.BookTblTableAdapter bookTblTableAdapter2;
        private System.Windows.Forms.ComboBox TypeCb;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2DataGridView MemberSDGV;
    }
}